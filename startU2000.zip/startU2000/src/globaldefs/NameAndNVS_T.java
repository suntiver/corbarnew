package globaldefs;

/**
 * Generated from IDL struct "NameAndNVS_T".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 2010-12-18 17:25:57
 */

public final class NameAndNVS_T
	implements org.omg.CORBA.portable.IDLEntity
{
	public NameAndNVS_T(){}
	public globaldefs.NameAndStringValue_T[] name;
	public globaldefs.NameAndStringValue_T[] additionalInfo;
	public NameAndNVS_T(globaldefs.NameAndStringValue_T[] name, globaldefs.NameAndStringValue_T[] additionalInfo)
	{
		this.name = name;
		this.additionalInfo = additionalInfo;
	}
}
