package globaldefs;
/**
 * Generated from IDL const "interfaceVersion".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 2010-12-18 17:25:57
 */

public interface interfaceVersion
{
	java.lang.String value = "V2.02.02";
}
