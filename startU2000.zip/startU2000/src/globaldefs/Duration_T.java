package globaldefs;

/**
 * Generated from IDL struct "Duration_T".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 2010-12-18 17:25:57
 */

public final class Duration_T
	implements org.omg.CORBA.portable.IDLEntity
{
	public Duration_T(){}
	public java.lang.String fromTime;
	public java.lang.String toTime;
	public Duration_T(java.lang.String fromTime, java.lang.String toTime)
	{
		this.fromTime = fromTime;
		this.toTime = toTime;
	}
}
