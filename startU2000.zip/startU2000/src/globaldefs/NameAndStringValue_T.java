package globaldefs;

/**
 * Generated from IDL struct "NameAndStringValue_T".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 2010-12-18 17:25:57
 */

public final class NameAndStringValue_T
	implements org.omg.CORBA.portable.IDLEntity
{
	public NameAndStringValue_T(){}
	public java.lang.String name = "";
	public java.lang.String value = "";
	public NameAndStringValue_T(java.lang.String name, java.lang.String value)
	{
		this.name = name;
		this.value = value;
	}
}
