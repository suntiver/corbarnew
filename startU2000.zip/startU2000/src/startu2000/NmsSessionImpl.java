/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startu2000;

import session.Session_I;

/**
 *
 * @author lenovo
 */
public class NmsSessionImpl extends nmsSession.NmsSession_IPOA{

    @Override
    public void eventLossOccurred(String startTime, String notificationId) {
       
        System.out.println("Called eventLossCleared...");
        
    }

    @Override
    public void eventLossCleared(String endTime) {
 
        System.out.println("call eventLossCleared...");
        
    }

    @Override
    public Session_I associatedSession() {
     
        // TODO Auto-generated method stub
	return null;
        
    }

    @Override
    public void ping() {
                 System.out.println("Called ping...");
    }

    @Override
    public void endSession(int sessionID) {
      System.out.println("Called endSession...");
    }
    
}
