/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startu2000;


import CosNotification.Property;
import CosNotification.StructuredEvent;
import common.Common_IHolder;
import emsMgr.EMSMgr_I;
import emsMgr.EMS_T;
import emsMgr.EMS_THolder;
import emsSession.EmsSession_I;
import emsSession.EmsSession_IHolder;
import emsSessionFactory.EmsSessionFactory_I;
import emsSessionFactory.EmsSessionFactory_IHelper;
import globaldefs.ProcessingFailureException;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import nmsSession.NmsSession_I;
import nmsSession.NmsSession_IPOA;
import notifications.EventIterator_IHolder;
import notifications.EventList_THolder;
import notifications.PerceivedSeverity_T;
import org.omg.CORBA.IntHolder;
import org.omg.CORBA.ORB;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextHelper;


public class StartU2000 {
    static ORB orb;     
    static EMSMgr_I emsMgr = null;     
    static EmsSession_I emsSession=null;     
    static EMS_THolder emsHolder = null; 
    static EMS_T ems = null;  
    static IntHolder id = null;
    static Date start_time=new Date();   
    static Date end_time=new Date();   
    public static void  testCorba() throws UnsupportedEncodingException{
        
      
        
        try {
            String[] args = new String[2];
            args[0] = "-ORBInitRef";   
            args[1] = "NameService=corbaloc::192.168.1.17:900/NameService";       
            orb = org.omg.CORBA.ORB.init(args, null);    
            
           
            
        } catch (Exception e) {
            System.out.println("ORB มีปัญหา");
        }
        
        NamingContext  namingContext = null;
        org.omg.CORBA.Object objRef = null;
        
        try {
            
            objRef = orb.resolve_initial_references("NameService");
            namingContext = NamingContextHelper.narrow(objRef);
            System.out.println("รับบริการชื่อสำเร็จ"+namingContext);
            
        } catch (Exception e) {
            
            System.out.println("มีปัญหากับบริการ");
        }
        
        NameComponent path[] = new NameComponent[5];
        path[0] = new NameComponent("TMF_MTNM","Class");
        path[1] = new NameComponent("HUAWEI","Vendor");
        path[2] = new NameComponent("Huawei/U2000","EmsInstance");
        path[3] = new NameComponent("2.0","Version");
        path[4] = new NameComponent("Huawei/U2000","EmsSessionFactory_I");
        
      
        EmsSessionFactory_I emsSessionFactory_I = null; 
        org.omg.CORBA.Object obj = null; 
        try{              
             obj = namingContext.resolve(path);   
            System.out.println("obj=>"+obj);   
            emsSessionFactory_I = EmsSessionFactory_IHelper.narrow(obj);   
            System.out.println("emsSessionFactory_I=>"+emsSessionFactory_I);   
        }catch(Exception e){  
            System.out.println("emsSessionFactory มีปัญหา");
            e.printStackTrace();   
        }
        
        EmsSession_IHolder sessionHolder = new EmsSession_IHolder(); 
        
        //Log In and Retrieve EmsSession
        try {
            NmsSession_IPOA pNmsSessionServant = new NmsSessionImpl();
            NmsSession_I nmsSession =  pNmsSessionServant._this(orb);
            if (emsSessionFactory_I != null){
                emsSessionFactory_I.getEmsSession("admin","P@ssw0rd", nmsSession, sessionHolder);
                emsSession = sessionHolder.value; 
                System.out.println("Log in success");
            }
            else{
                return;               
            }
        } catch (globaldefs.ProcessingFailureException ex) {
           System.out.println("Get the EmsSession reference object, exception! ---ProcessingFailureException---");    
            System.out.println("It may be that the username or password is incorrect, or the permissions are not enough [Corba OSS User], or the logged in user has not logged out!");    
            System.out.println(ex.toString());
            showMessage(ex.errorReason);
 
        }

        Common_IHolder common_IHolder = new Common_IHolder();
           try {
            String[] excludeProbCauseList=new String[0];
            PerceivedSeverity_T[] excludeSeverityList=new PerceivedSeverity_T[0];
            EventList_THolder eventList=new EventList_THolder();
            EventIterator_IHolder eventIt=new EventIterator_IHolder();
            int how_many=10;
            start_time=new Date();
            emsMgr.getAllEMSAndMEActiveAlarms(excludeProbCauseList, excludeSeverityList, how_many, eventList, eventIt);
            end_time=new Date();
            System.out.println("getAllEMSAndMEActiveAlarms:"+start_time.toString()+"-"+end_time.toString());
            StructuredEvent[] events= eventList.value; 
            for (int i=0;i<events.length;i++){               
                Property[] propertyList= events[i].filterable_data;
                showMessage("event:"+i);
                for (int j=0;j<propertyList.length;j++){
                    try{
                        showMessage("    "+propertyList[j].name+","+ propertyList[j].value);
                        Object prop_obj=propertyList[j].value.extract_Object();
                    }
                    catch(Exception e){
                        continue;
                    }
                }
 
            }
               
            
        } catch (ProcessingFailureException e) {   
            System.out.println("Processing Exception" + e.getMessage()); 
            e.printStackTrace();   
            showMessage(e.errorReason);
        }
         finally{
//            emsSession.endSession();
        }
        
        
        
    }
    
    
      public static void showMessage(String msg) throws UnsupportedEncodingException  {
        byte[] bytes=msg.getBytes("ISO-8859-1");       
        String rlt = new String(bytes, "GBK");           
        System.out.println(rlt);   
    }
    
    
    public static void main(String[] args) throws UnsupportedEncodingException {
        // TODO code application logic here
        
        
        testCorba();
        
        //ถ้า เกิด  Error ให้กลับไป  ดูของ emsMgr .ใใใใใใใใใใใใใใใใใใใใใใใใใใใ
        
    }
    
}
