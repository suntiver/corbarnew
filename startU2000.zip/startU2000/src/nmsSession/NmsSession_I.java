package nmsSession;

/**
 * Generated from IDL interface "NmsSession_I".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 2010-12-23 15:36:26
 */

public interface NmsSession_I
	extends NmsSession_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity, session.Session_I
{
}
