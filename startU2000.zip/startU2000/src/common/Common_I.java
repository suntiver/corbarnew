package common;

/**
 * Generated from IDL interface "Common_I".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 2010-12-18 17:25:51
 */

public interface Common_I
	extends Common_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
