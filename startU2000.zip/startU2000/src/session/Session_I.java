package session;

/**
 * Generated from IDL interface "Session_I".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 2010-12-23 15:36:29
 */

public interface Session_I
	extends Session_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
