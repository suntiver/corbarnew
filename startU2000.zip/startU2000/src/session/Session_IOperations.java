package session;


/**
 * Generated from IDL interface "Session_I".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 2010-12-23 15:36:29
 */

public interface Session_IOperations
{
	/* constants */
	/* operations  */
	session.Session_I associatedSession();
	void ping();
	void endSession(int sessionID);
}
