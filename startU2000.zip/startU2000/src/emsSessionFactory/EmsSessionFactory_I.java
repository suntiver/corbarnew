package emsSessionFactory;

/**
 * Generated from IDL interface "EmsSessionFactory_I".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 2010-12-23 15:44:08
 */

public interface EmsSessionFactory_I
	extends EmsSessionFactory_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
